import { DayPicker } from "react-day-picker"
import type { DayPickerProps } from "react-day-picker"

function CustomCalendar(props: DayPickerProps) {
  return <DayPicker {...props} />
}
