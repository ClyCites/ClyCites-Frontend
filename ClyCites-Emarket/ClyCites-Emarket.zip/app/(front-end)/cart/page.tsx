import React from 'react'

export default function Cart() {
  return (
    <div className='flex justify-center items-center h-screen '>
      <h2 className='text-4xl'>Welcome to the Shopping Cart</h2>
    </div>
  )
}