import React from 'react'

export default function UpdateCategory() {
  return (
    <div>
      <h2>update Category</h2>
    </div>
  )
}
