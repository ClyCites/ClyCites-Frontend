import React from 'react'

export default function UpdateBanner() {
  return (
    <div>
      <h2>update Banner</h2>
    </div>
  )
}
