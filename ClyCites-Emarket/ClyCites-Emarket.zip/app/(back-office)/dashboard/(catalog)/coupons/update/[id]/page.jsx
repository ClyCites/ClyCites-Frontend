import React from 'react'

export default function UpdateCoupon() {
  return (
    <div>
      <h2>update Coupon</h2>
    </div>
  )
}
