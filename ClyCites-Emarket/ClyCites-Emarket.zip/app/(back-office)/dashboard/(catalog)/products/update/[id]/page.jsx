import React from 'react'

export default function UpdateProduct() {
  return (
    <div>
      <h2>update Product</h2>
    </div>
  )
}
