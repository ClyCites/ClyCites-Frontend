import React from 'react'

export default function UpdateTrainings() {
  return (
    <div>
      <h2>update Community</h2>
    </div>
  )
}
