import React from 'react'

export default function UpdateFarmer() {
  return (
    <div>
      <h2>update Farmer</h2>
    </div>
  )
}
