import React from 'react'

export default function UpdateStaff() {
  return (
    <div>
      <h2>update Staff</h2>
    </div>
  )
}
