import React from 'react'

export default function page() {
  return (
    <div>
      <h2>Customers</h2>
    </div>
  )
}
